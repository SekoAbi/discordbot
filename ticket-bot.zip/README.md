### 🎫 Discord Modals Simple Ticket Bot:

#### Again, a bot infrastructure I made in my spare time, I actually made it for my own server, but I thought and shared it with people, I hope it can be useful for you, good coding.

<hr />

### Setup:

#### Hey now there's a video to use the bot you can watch: https://youtu.be/gv94bxO-jo0

#### Note: You must have Node.js version 16.9.0 or higher installed on your computer. (Download link if not installed https://nodejs.org)

#### 1 - Open a terminal and type `npm install yarn --g` and wait for it to install.

#### 2 - Open terminal in infrastructure file, type `yarn install` and install all necessary modules.

#### 3 - After installing the modules, fill in the `config.js` file.

#### 4 - After doing the above 3 items, open a terminal in the folder and type `node src/index.js` then your bot will run actively. (Instead of opening a terminal, you can create a .bat file and type the command you will type in the terminal.)
