import Discord from "discord.js";
const { ButtonStyle, TextInputStyle } = Discord;

export default {
  PREFIX: "!",
  TOKEN: "MTAwNzM0MzA1NjI0MjA5ODE3Nw.GLdIMC.EzkS8fdE2JPagsy6LwZXvj1UatEs63DwRXeJHQ",
  ACTIVITY: { NAME: "Clean Creations", TYPE: "WATCHING" },
  GUILD_ID: "1001995398459691152",
  TICKET: {
    CHANNEL: "1001995399214682131",
    CATEGORY: "1001995399587962955",
    ARCHIVE_CATEGORY: "1007373726481907822",
    MESSAGE: "**Info:** Click on the reactive button below \nto create a ticket!\n\n **Place a Custom Order **\n or\n **Purchase a Product**",
    STAFF_ROLES: ["1001995398459691155", "1001995398459691154"],
    BUTTONS: [
      {
        STYLE: ButtonStyle.Danger,
        LABEL: " ",
        EMOTE: "🎟️",
        ID: "deleteTicket",
        DISABLED: false,
      },
    ],
    QUESTIONS: [
      {
        ID: "name",
        LABEL: "Whats your name?",
        STYLE: TextInputStyle.Short,
        MIN_LENGTH: 4,
        MAX_LENGTH: 16,
        PLACE_HOLDER: "Your Name.",
        REQUIRED: true,
      },
      {
        ID: "age",
        LABEL: "What kind of order?",
        STYLE: TextInputStyle.Short,
        MIN_LENGTH: 1,
        MAX_LENGTH: 60,
        PLACE_HOLDER: "Custom order/Purchase",
        REQUIRED: true,
      },
    ],
  },
};
