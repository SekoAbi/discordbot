import { Client, GatewayIntentBits } from "discord.js";
const Bot = (global.bot = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
  ],
}));
import Utils from "./utils/utils.js";
const keep_alive = require('./keep_alive.cjs')
keepAlive();

Utils.event(Bot);
Utils.login(Bot);


